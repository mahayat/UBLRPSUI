This dataset contains 12 images taken with Unmanned Areal Vehicle (UAV). These images have the filename ending with '_UAV.jpg'. The corresponding manual panicle detection of these 12 images have filename ending with '_MAN.jpg'. Filename of Image #1 starts with 'I1' and so forth for following images. Filename and resolution of images in this database are as follows.

Image	Distance	Resolution

I1	3m 		820 � 865
I2	3m 		810 � 800  
I3	3m 		1050 � 1075  
I4	3m 		1050 � 1050  
I5	3m 		1080 � 1040  
I6	3m 		1120 � 1070 
I7	6m 		415 � 410 
I8	6m 		440 � 415 
I9	6m 		430 � 430 
I10	6m 		445 x 440
I11	6m 		430 � 430   
I12	6m 		430 � 420  

This dataset has been used in article 'Unsupervised Bayesian Learning for Rice Panicle Segmentation with UAV Images'
